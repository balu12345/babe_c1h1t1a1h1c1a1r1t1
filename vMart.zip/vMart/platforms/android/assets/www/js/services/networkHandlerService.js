angular.module('myApp.networkHandlerService', ['ngRoute'])

.service('networkHandlerService', ['$http', function ($http) {

	this.homeOfferProducts = function () {
		return $http.get('resources/productDetails.json');
	};

	this.loadMoreSearchResults = function () {
		return $http.get('http://www.reddit.com/r/Android/new/.json');
	};

	this.loadCartItems = function () {
		return $http.get('resources/cartItems.json');
	};

	this.loadProducts = function () {
		return $http.get('http://www.reddit.com/r/Android/new/.json');
	};

	this.loadMoreCoupons = function () {
		return $http.get('resources/coupons.json');
	};

	this.loadNewCoupons = function () {
		return $http.get('resources/coupons.json');
	};

	this.loadMoreOffers = function () {
		return $http.get('resources/offers.json');
	};

	this.loadNewOffers = function () {
		return $http.get('resources/offers.json');
	};

}]);
