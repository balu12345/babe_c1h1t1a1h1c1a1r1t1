angular.module('myApp.controllers', [])

.controller('appCtrl',['$scope', '$state', '$http' ,function($scope, $state, $http) {
}]);
